console.log("JavaScript working ? - Yes !");
