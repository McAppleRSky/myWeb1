document.writeln("<form name=/"gobarform/" width=100%  border=0>"
  +"<td width=95% bgcolor=gray align=left>"
  +"<font color=white></font></td></font>");
