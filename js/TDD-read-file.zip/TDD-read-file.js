filelistObject = document.createElement("object");
filelistObject.setAttribute("data","img/list");
filelistObject.setAttribute("type","text/plain");
document.appendChild(filelistObject);
